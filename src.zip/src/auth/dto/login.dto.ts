export class LoginDto {
   username: string;
   password: string;
 }