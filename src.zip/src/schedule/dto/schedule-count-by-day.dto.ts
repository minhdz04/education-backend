// schedule-count-by-day.dto.ts
export class ScheduleCountByDayDto {
  day: number;
  count: number;
}
