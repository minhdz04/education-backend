export class CreateSubject{
   
   name: string;
}