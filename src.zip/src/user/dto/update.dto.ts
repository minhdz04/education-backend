export class UpdateDto {
   
   username?: string;
   password?: string;
  
   // Thêm các trường khác bạn muốn cập nhật
 }