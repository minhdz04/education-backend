export class UserDto {
   sub: string;
   username: string;
 }